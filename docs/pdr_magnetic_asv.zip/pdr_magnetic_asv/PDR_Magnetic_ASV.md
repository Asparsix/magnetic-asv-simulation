# Preliminary Design Review (PDR)
# Cooperative Magnetic Anomaly Search with Multi-ASV Swarm

| Field | Value |
|-------|-------|
| Document type | Preliminary Design Review |
| Stack | ROS 2 Jazzy · Gazebo Harmonic · `version_3` |
| Demo | `ros2 launch boat_bringup multi_asv_phase4.launch.py` (`num_asvs:=3`) |
| Lake | \(300\times300\,\mathrm{m}\) (`niot_world`) |
| Planted target (eval only) | \((85.0,\ 40.0)\,\mathrm{m}\) |
| Evidence run | Completed Phase-4 mission → `MISSION_COMPLETE` (verifier ASV1, 4/4) |

**Figures** are under `docs/pdr_magnetic_asv/figures/`.  
**Companion deep-dive:** `docs/MAGNETIC_ASV_ROS2_DEVELOPER_MANUAL.md` · node catalog `version_3/docs/ros2_node_catalog.md`.

---

## 1. Purpose of this PDR

This PDR states **exactly how we search, localize, and confirm** a magnetic dipole with three ASVs: the operational concept, the mathematics, the ROS dataflow, the state machine, and **measured simulation evidence** (Gazebo + operator console screenshots + localization errors from a completed run).

**Review goal:** Accept the architecture and pipeline as the basis for continued implementation / competition submission.

---

## 2. Concept of operations (what we are doing)

### 2.1 Problem

Detect and localize a **compact magnetic anomaly** on a bounded lake. ASVs never receive the ground-truth coordinates. They only sense magnetometer readings that include Earth field + noise + a weak \(1/r^3\)-like anomaly.

### 2.2 Concept (one slide)

```
STRIP LAWNMOWER coverage (3 boats, dead corridor)
        │
        ▼  cleaned anomaly ≥ 15 nT hits → shared Bayes map
BELIEF peaks near a boat
        │
        ▼
INFO-GAIN hunt → inland-safe SPIRAL densify
        │
        ▼
DISCOVERER HOLDs + declares candidate
        │
        ▼
PEER VERIFIER orbits + counts 4 confirmations
        │
        ▼
SWARM COMPLETE / HALT   +  offline score ‖fix − target*‖
```

### 2.3 Why this strategy

| Choice | Reason |
|--------|--------|
| Vertical **strips + gap** | Avoid mid-lake path collisions of shared-seam Voronoi |
| Shared **/swarm/belief** | All boats improve one map; discoverer ≠ only sensor |
| **Info-gain → spiral** | First move for information, then angular densification for dipole fit |
| **Peer verify** | Independent confirmation reduces false COMPLETE |
| **Inland spiral radius** | Prevents shoreline collider flings that kill odom |

---

## 3. Simulation plant (Gazebo evidence)

![Gazebo `niot_world`](figures/fig_gazebo_world.png)

**Figure 1 — Gazebo Harmonic plant.** World `niot_world`, physics `gz-physics-dartsim-plugin`, shore walls (`north/south/east/west_shore`), `water_surface`, dock/buoys, and ASV models (`simple_boat{,_2,_3}`). Actuation is propeller thrust bridged from ROS; sensing includes IMU, GPS, magnetometer, odometry.

Operator overview (Gazebo + console together):

![Desktop overview](figures/fig_desktop_overview.png)

**Figure 2 — Desktop during Phase-4 bring-up** (Gazebo GUI + trajectory/mission console).

---

## 4. Exact runtime workflow (step by step)

### Step 0 — Launch graph

`multi_asv_phase4.launch.py` → `sim.launch.py` with `num_asvs:=3`, sensing/mapping/mission/autonomy on.

Order: Gazebo → `boat_bridge` (+ clock if fast) → per-ASV `{thrust_mixer, gazebo_pose2d, los_path_follower, mag_*, calibration, mission_manager}` → `verify_coordinator` → `trajectory_plotter` → `bayes_fusion`.

Namespaces: `/asv1`↔`simple_boat`, `/asv2`↔`simple_boat_2`, `/asv3`↔`simple_boat_3`.

### Step 1 — GLOBAL_SEARCH (lawnmower)

Each `mission_manager` publishes a strip lawnmower on `plan` (TRANSIENT_LOCAL). LOS follows; sensing runs continuously.

![SEARCH phase console](figures/fig_operator_console_search.png)

**Figure 3 — LIVE SEARCH.** Three strip routes, boats heading east on south shore, true target marked at \((85,40)\), mag ≪ 15 nT hit line, modes `GLOBAL_SEARCH`. Early centroid error large (~94 m) because belief is still uniform / uninformative (\(p=0.00\), \(\sigma\approx122\,\mathrm{m}\)).

**Mode exit → TARGET_SEARCH when:**
- calibration `READY` (if required),
- \(t \ge 20\,\mathrm{s}\),
- **4 consecutive** ticks with \(p^\star \ge 0.25\) and distance to estimate \(\le 150\,\mathrm{m}\).

### Step 2 — TARGET_SEARCH / INFO_GAIN

Mutual-information waypoints on rings \(\{10,20,30\}\,\mathrm{m}\). Leave when MI collapses, near estimate, step budget, or high \(p^\star\) near peak.

### Step 3 — TARGET_SEARCH / SPIRAL (inland-safe)

Expanding rings about belief centroid / estimate. Usable radius:

\[
r_{\max}^{\mathrm{use}}
=\min\big(80,\ \mathrm{dist}(\mathrm{center},\partial\mathrm{box})-10\big)\,\mathrm{m}.
\]

No wall-clamping (prevents Gazebo shore flings). Evidence run: ASV3 spiral had **9 waypoints** around \(\sim(99,15)\).

### Step 4 — HOLD + declare

Discoverer publishes **empty** `plan` (LOS → zero `cmd_vel`), then `/swarm/verify/declare`.  
Non-verifier peers that see a request for someone else also HOLD and clear path.

**Evidence (log):** ASV3 declared candidate \((95.0,15.0)\) at \(p=0.956\); ASV2 HOLD for verifier ASV1.

### Step 5 — VERIFY (peer orbit)

Coordinator prefers other ASV (`prefer_other_verifier: true`). Verifier flies opposite-approach orbit (radius ≤ fit, transit hops ~40 m). Each mag sample can add a confirmation if:

| Gate | Threshold |
|------|-----------|
| Distance to candidate | \(\le 30\,\mathrm{m}\) |
| Belief peak near candidate | \(\le 50\,\mathrm{m}\) |
| Cleaned anomaly | \(\ge 15\,\mathrm{nT}\) |
| Peak probability | \(\ge 0.30\) |

Need **4** confirms → `/swarm/verify/result` success.

![Hunt / verify era console](figures/fig_hunt_verify_console.png)

**Figure 4 — Earlier hunt/verify console snapshot** (mission phase strip in VERIFY; magnetic spike above 15 nT; multi-boat tracks near east strip / target region). Used as mid-mission evidence; Gazebo must stay alive for odom continuity.

### Step 6 — COMPLETE

Coordinator latches `/swarm/mission/complete` + `/swarm/mission/halt`. All boats stop. Plotter shows CONFIRMED.

**Evidence:**  
`MISSION_COMPLETE:verifier=asv1:conf=4:p=0.521`

---

## 5. Exact mathematics (design equations)

### 5.1 Planted dipole (simulation evaluation only)

\[
a(\mathbf{p})=\frac{A}{r^{3}+s^{3}},\quad
r=\lVert\mathbf{p}-\mathbf{t}^{\star}\rVert_2
\]

Defaults: \(A=4\times10^5\), \(s=20\,\mathrm{m}\) ⇒ \(a(\mathbf{t}^{\star})=50\,\mathrm{nT}\).  
\(\mathbf{t}^{\star}=(85,40)\) in current `sensing.yaml`. Background \(45000\,\mathrm{nT}\) + \(\mathcal N(0,3^2)\,\mathrm{nT}\) noise. Estimators never read \(\mathbf{t}^{\star}\).

### 5.2 Detection probability (Bayes update)

\[
P_{\mathrm{det}}(d)=P_{\mathrm{bg}}+(P_{\max}-P_{\mathrm{bg}})
\frac{d_{1/2}^{3}}{d^{3}+d_{1/2}^{3}}
\]

\(P_{\mathrm{bg}}=0.05\), \(P_{\max}=0.95\), \(d_{1/2}=30\,\mathrm{m}\).

HIT if cleaned anomaly \(\ge15\,\mathrm{nT}\) (`hit_only: true` ignores MISS). On HIT:

\[
b_k\leftarrow b_k P_{\mathrm{det}}(d_k),\qquad b\leftarrow b/\sum_j b_j.
\]

Peak \(=\arg\max b_k\). Centroid = mass-weighted cells with \(b_k\ge 0.5 b_{\max}\).

### 5.3 Dipole least-squares fix

Fit \((t_x,t_y,A)\) of same \(A/(r^3+s^3)\) to strong samples → `/swarm/belief/fix` (continuous localization used for offline error).

### 5.4 Mutual information (hunt)

\[
I(\mathbf{c})=H(b)-\mathbb{E}\big[H(b'\mid\mathrm{HIT/MISS})\big],\quad
H(b)=-\sum_k b_k\log b_k.
\]

### 5.5 LOS guidance

\[
\psi_{\mathrm{LOS}}=\psi_{\mathrm{path}}+\operatorname{atan2}(-e_\perp,L),\quad L=15\,\mathrm{m}.
\]

Surge open-loop \(u_{\mathrm{ref}}=0.35\,\mathrm{m/s}\). Mixer \(T_{L,R}=\mathrm{clip}((u\mp\omega g)S)\).

### 5.6 Strip coverage

Coverage box \(\pm120\,\mathrm{m}\). Three vertical strips, gap \(20\,\mathrm{m}\), row spacing \(15\,\mathrm{m}\). Spawns on strip starts facing east.

---

## 6. ROS architecture (exact interface digest)

```
Gazebo ──bridge──► /asvN/{odom,imu,gps,mag/gazebo}
gazebo_pose2d ──► pose2d
mag_driver → mag/raw → mag_filter → mag/filtered → calibration → mag/anomaly
                                                      │
                                      bayes_fusion ◄──┘ (all ASVs)
                                      /swarm/belief/{map,peak,centroid,fix,…}
mission_manager ◄── pose, anomaly, cal, belief
        │ plan
los_path_follower ──► cmd_vel ──► thrust_mixer ──► /model/.../cmd_thrust
verify_coordinator: declare → request → result → complete/halt
```

**Critical QoS:** `plan`, `/swarm/mission/complete|halt|status` are TRANSIENT_LOCAL — always kill old stacks / change `ROS_DOMAIN_ID` before a new demo, or you latch a ghost CONFIRMED.

Full topic/parameter tables: `version_3/docs/ros2_node_catalog.md`.

---

## 7. Mission FSM (exact logic)

| Mode | Hunt phase | Action |
|------|------------|--------|
| `GLOBAL_SEARCH` | — | Strip lawnmower |
| `TARGET_SEARCH` | `INFO_GAIN` | MI surfing |
| `TARGET_SEARCH` | `SPIRAL` | Inland densify |
| `HOLD` | — | Empty plan (stop); wait / clear for peer |
| `VERIFY` | — | Orbit + confirmation counter |
| `COMPLETE` | — | Swarm halted |

Handshake:

1. Discoverer → `/swarm/verify/declare`  
2. Coordinator → `/swarm/verify/request` (prefer other ASV)  
3. Verifier → `/swarm/verify/result`  
4. Coordinator → `/swarm/mission/complete` + `halt`

Multi-ASV: `self_verify: false` (discoverer does not self-orbit after declare).

---

## 8. Simulation results / “error report” (measured)

From the completed Phase-4 run (`/tmp/sim_run.log` + latched swarm status):

### 8.1 Software mission success

| Item | Value |
|------|-------|
| Outcome | **MISSION_COMPLETE** |
| Verifier | `asv1` |
| Confirmations | **4 / 4** |
| Peak \(p\) at complete | \(\approx 0.521\) |
| Declared candidate | \((95.0,\ 15.0)\) by **ASV3**, \(p=0.956\) |
| Planted truth | \((85.0,\ 40.0)\) |

### 8.2 Localization error vs planted target

Error metric used for evaluation:

\[
e_{\mathrm{fix}}=\big\lVert \mathbf{t}_{\mathrm{fix}}-\mathbf{t}^{\star}\big\rVert_2,\quad
\mathbf{t}^{\star}=(85,40).
\]

| Metric | Value |
|--------|-------|
| Best dipole fix observed | **\(\approx 0.0\,\mathrm{m}\)** at exactly \((85.0,40.0)\), RMS \(\approx1.4\,\mathrm{nT}\) |
| Example mid-verify fixes | \((85.0,43.3)\Rightarrow e\approx3.3\,\mathrm{m}\); \((84.8,41.3)\Rightarrow e\approx1.3\,\mathrm{m}\) |
| Median \(e_{\mathrm{fix}}\) over last 50 published fixes | \(\approx 5.8\,\mathrm{m}\) |

**Interpretation for judges:** Software CONFIRMED means verify protocol succeeded. Continuous localization (`/swarm/belief/fix`) during densified sampling reaches **metre-class** agreement with the planted dipole; early SEARCH centroid error (~90 m) is expected before HITs.

### 8.3 Timeline extracted from logs

1. Plant dipole \((85,40)\); publish 3 strip lawnmowers (34 verts each).  
2. ASV3: `TARGET_SEARCH` → short inland `SPIRAL` → `HOLD` → declare.  
3. ASV2: `HOLD` (clear path).  
4. ASV1: `VERIFY` → 4 confirms → `MISSION COMPLETE`.  
5. Swarm halt clears all LOS paths.

Raw snapshot JSON: `figures/completed_run_metrics.json` · `figures/RESULTS_SUMMARY.txt`.

---

## 9. Risks observed and mitigations (PDR frankness)

| Risk / failure seen in lab | Mitigation now in stack |
|----------------------------|-------------------------|
| Spiral clamp-to-wall → Gazebo fling → dead odom → verifier “stuck” | Inland radius shrink; empty-plan HOLD |
| Two boats spiraling same peak | Non-verifier HOLD on verify request |
| Ghost nodes latch false CONFIRMED | Kill all stacks; new `ROS_DOMAIN_ID` |
| Instant CONFIRMED with huge centroid error | Treat CONFIRMED as protocol success; score `fix` offline |

---

## 10. Acceptance criteria proposed at PDR

1. Three ASVs complete strip SEARCH without mutual collision routes.  
2. At least one boat transitions SEARCH→HUNT after authentic ≥15 nT HITs.  
3. Peer VERIFY reaches 4/4 confirmations and latches COMPLETE.  
4. During densified sampling, \(e_{\mathrm{fix}}\) reaches **\< 10 m** (stretch: \< 5 m).  
5. No ASV leaves the lake shore box without recoverable odom.

**This evidence run meets (1)–(4)** on the completed log; stretch goal of continuous \<5 m is intermittently met (best 0 m; late median ~5.8 m).

---

## 11. How to reproduce for the review board

```bash
cd /home/robot/simulation_ws/version_3
# kill prior gz / ros / thrust_mixer completely first
source /opt/ros/jazzy/setup.bash && source install/setup.bash
export ROS_DOMAIN_ID=44
ros2 launch boat_bringup multi_asv_phase4.launch.py
```

Inspect:

```bash
ros2 topic echo /swarm/mission/status --once
ros2 topic echo /swarm/belief/fix --once
# compare to planted (85,40)
```

---

## 12. Document package checklist

| Artifact | Path |
|----------|------|
| **This PDR** | `docs/pdr_magnetic_asv/PDR_Magnetic_ASV.md` |
| Figures | `docs/pdr_magnetic_asv/figures/` |
| Results text | `figures/RESULTS_SUMMARY.txt` |
| Long ROS manual | `docs/MAGNETIC_ASV_ROS2_DEVELOPER_MANUAL.md` |
| Node catalog | `version_3/docs/ros2_node_catalog.md` |
| Overleaf book | `docs/overleaf_magnetic_asv/` (+ zip) |

---

*End of PDR. Screenshots: Figures 1–4. Errors: §8. Math: §5. Workflow: §4. FSM: §7.*
